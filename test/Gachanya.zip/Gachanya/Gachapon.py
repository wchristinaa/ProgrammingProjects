class Gachapon():

    x=0
    y=0
    
    def display(self):
     # display gachapon image
        gachaponm = loadImage("gachapon.png")
        image(gachaponm, x, y)

    def __turn__(self):
        if key == 'e':
            return True
        else:
            return False

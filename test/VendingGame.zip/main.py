import random
global money
money=0
def back():
  print('welcome to Gyacha!')
  print('select an option:')
  start=input('𝓹𝓵𝓪𝔂\n 𝖎𝖓𝖘𝖙𝖗𝖚𝖈𝖙𝖎𝖔𝖓𝖘\n 𝖈𝖗𝖊𝖉𝖎𝖙𝖘\n')
  if start.lower()=='credits':
    print('This game was created by Christina Wu') 
  elif start.lower()=='instructions':
      print('Get money by answering trivia questions. \n Use the money to buy stuff from the vending \n machine, try to collect all the items!\n\n HOW TO PLAY \n When the options pop up type in lowercase \nletters.')
  #play
  elif start.lower()=='play':
      play=input('\ngacha \n guessing\n balance \n')
  #balance
  if play.lower()=='balance':
    print('current balance:',money)
    global e
    e=input('back?\n option:yes \n')
    if e.lower()=='yes':
      back()
  #guessing
  if play.lower()=='guessing':
    num = random.randint(0,50)
    guesses = 5

    print('Welcome to the number guessing game! You have 5 guesses, the numbers \n range from 1-50, good luck.')
    while (guesses>=1):
      guesses=guesses-1
      test = input('input number: ') 
      if int(test)>num:
       print('you said', test, 'its too high','you have',guesses,"guesses left")
      elif int(test)<num:
         print('you said',test,'its too low','you have',guesses,"guesses left")
      elif int(test)==num:
       print('you win!')
       money=money+10
       g=input('back?\n option:yes \n')
       if g.lower()=='yes':
        back()
    else:
     print('you lose.. the number was ',num)
     f=input('back?\n option:yes \n')
     if f.lower()=='yes':
          back()
  #back option
#implement
  if play.lower()=='gacha':
    if money>9:
      purchase=input('would you like to purchase a roll?')
      if purchase.lower()=='yes':
        prize=["bear", "headphones", "small dinosaur", "toy car", "key", "trash", "drink", "apple", "keyboard"]
        print('you won:', random.choice(prize))
      elif purchase.lower()=='no':
        print('sorry')
        e=input('back?\n option:yes \n')
        if e.lower()=='yes':
          back()
    if money<10:
      print('sorry you cant afford it')
      e=input('back?\n option:yes \n')
      if e.lower()=='yes':
         back()
back()